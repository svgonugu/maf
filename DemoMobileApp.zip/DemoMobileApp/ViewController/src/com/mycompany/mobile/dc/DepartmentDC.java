package com.mycompany.mobile.dc;

import com.mycompany.mobile.common.CmnRestAdapter;
import com.mycompany.mobile.common.ItemsList;
import com.mycompany.mobile.entity.Department;

import oracle.adfmf.framework.exception.AdfException;

public class DepartmentDC
{
    public Department[] getDepartments()
    {
       ItemsList<Department> deptList = null;
                 
       String response = CmnRestAdapter.doGET("?expand=Employee", null);
       try
       {
         deptList = CmnRestAdapter.deserializeToItemsList(response, Department.class);
       }catch(Exception e)
       {
          throw new AdfException(e.getCause(), AdfException.ERROR);
       }
       return deptList.getItems();
    }

}
