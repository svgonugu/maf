package com.mycompany.mobile.entity;

import java.util.Date;

import oracle.adfmf.java.beans.PropertyChangeListener;
import oracle.adfmf.java.beans.PropertyChangeSupport;

public class Employee
{
   private long employeeId;
   private String firstName;
   private String lastName;
   private String email;
   private String phoneNumber;
   private Date hireDate;
   private String jobId;
   private Double salary;
   private Double commissionPct;
   private long managerId;
   private long departmentId;
   private String isactive;
   
   private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

   public void setEmployeeId(long employeeId)
   {
      long oldEmployeeId = this.employeeId;
      this.employeeId = employeeId;
      propertyChangeSupport.firePropertyChange("employeeId", oldEmployeeId, employeeId);
   }

   public long getEmployeeId()
   {
      return employeeId;
   }

   public void setFirstName(String firstName)
   {
      String oldFirstName = this.firstName;
      this.firstName = firstName;
      propertyChangeSupport.firePropertyChange("firstName", oldFirstName, firstName);
   }

   public String getFirstName()
   {
      return firstName;
   }

   public void setLastName(String lastName)
   {
      String oldLastName = this.lastName;
      this.lastName = lastName;
      propertyChangeSupport.firePropertyChange("lastName", oldLastName, lastName);
   }

   public String getLastName()
   {
      return lastName;
   }

   public void setEmail(String email)
   {
      String oldEmail = this.email;
      this.email = email;
      propertyChangeSupport.firePropertyChange("email", oldEmail, email);
   }

   public String getEmail()
   {
      return email;
   }

   public void setPhoneNumber(String phoneNumber)
   {
      String oldPhoneNumber = this.phoneNumber;
      this.phoneNumber = phoneNumber;
      propertyChangeSupport.firePropertyChange("phoneNumber", oldPhoneNumber, phoneNumber);
   }

   public String getPhoneNumber()
   {
      return phoneNumber;
   }

   public void setHireDate(Date hireDate)
   {
      Date oldHireDate = this.hireDate;
      this.hireDate = hireDate;
      propertyChangeSupport.firePropertyChange("hireDate", oldHireDate, hireDate);
   }

   public Date getHireDate()
   {
      return hireDate;
   }

   public void addPropertyChangeListener(PropertyChangeListener l)
   {
      propertyChangeSupport.addPropertyChangeListener(l);
   }

    public void setJobId(String jobId) {
        String oldJobId = this.jobId;
        this.jobId = jobId;
        propertyChangeSupport.firePropertyChange("jobId", oldJobId, jobId);
    }

    public String getJobId() {
        return jobId;
    }

    public void setSalary(Double salary) {
        Double oldSalary = this.salary;
        this.salary = salary;
        propertyChangeSupport.firePropertyChange("salary", oldSalary, salary);
    }

    public Double getSalary() {
        return salary;
    }

    public void setCommissionPct(Double commissionPct) {
        Double oldCommissionPct = this.commissionPct;
        this.commissionPct = commissionPct;
        propertyChangeSupport.firePropertyChange("commissionPct", oldCommissionPct, commissionPct);
    }

    public Double getCommissionPct() {
        return commissionPct;
    }

    public void setManagerId(long managerId) {
        long oldManagerId = this.managerId;
        this.managerId = managerId;
        propertyChangeSupport.firePropertyChange("managerId", oldManagerId, managerId);
    }

    public long getManagerId() {
        return managerId;
    }

    public void setDepartmentId(long departmentId) {
        long oldDepartmentId = this.departmentId;
        this.departmentId = departmentId;
        propertyChangeSupport.firePropertyChange("departmentId", oldDepartmentId, departmentId);
    }

    public long getDepartmentId() {
        return departmentId;
    }

    public void setIsactive(String isactive) {
        String oldIsactive = this.isactive;
        this.isactive = isactive;
        propertyChangeSupport.firePropertyChange("isactive", oldIsactive, isactive);
    }

    public String getIsactive() {
        return isactive;
    }

    public void setPropertyChangeSupport(PropertyChangeSupport propertyChangeSupport) {
        PropertyChangeSupport oldPropertyChangeSupport = this.propertyChangeSupport;
        this.propertyChangeSupport = propertyChangeSupport;
        propertyChangeSupport.firePropertyChange("propertyChangeSupport", oldPropertyChangeSupport,
                                                 propertyChangeSupport);
    }

    public PropertyChangeSupport getPropertyChangeSupport() {
        return propertyChangeSupport;
    }

    public void removePropertyChangeListener(PropertyChangeListener l)
   {
      propertyChangeSupport.removePropertyChangeListener(l);
   }
}
