package com.mycompany.mobile.entity;

import oracle.adfmf.java.beans.PropertyChangeListener;
import oracle.adfmf.java.beans.PropertyChangeSupport;

public class Department
{
   private long departmentId;
   private String departmentName;
   private long managerId;
   private long locationId;
   
   private Employee[] employee;
   private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

    public void setDepartmentId(long departmentId) {
        long oldDepartmentId = this.departmentId;
        this.departmentId = departmentId;
        propertyChangeSupport.firePropertyChange("departmentId", oldDepartmentId, departmentId);
    }

    public long getDepartmentId() {
        return departmentId;
    }

    public void setDepartmentName(String departmentName) {
        String oldDepartmentName = this.departmentName;
        this.departmentName = departmentName;
        propertyChangeSupport.firePropertyChange("departmentName", oldDepartmentName, departmentName);
    }

    public String getDepartmentName() {
        return departmentName;
    }

    public void setManagerId(long managerId) {
        long oldManagerId = this.managerId;
        this.managerId = managerId;
        propertyChangeSupport.firePropertyChange("managerId", oldManagerId, managerId);
    }

    public long getManagerId() {
        return managerId;
    }

    public void setLocationId(long locationId) {
        long oldLocationId = this.locationId;
        this.locationId = locationId;
        propertyChangeSupport.firePropertyChange("locationId", oldLocationId, locationId);
    }

    public long getLocationId() {
        return locationId;
    }

    public void setEmployee(Employee[] employee) {
        Employee[] oldEmployee = this.employee;
        this.employee = employee;
        propertyChangeSupport.firePropertyChange("employee", oldEmployee, employee);
    }

    public Employee[] getEmployee() {
        return employee;
    }

    public void addPropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.addPropertyChangeListener(l);
    }

    public void removePropertyChangeListener(PropertyChangeListener l) {
        propertyChangeSupport.removePropertyChangeListener(l);
    }
}
