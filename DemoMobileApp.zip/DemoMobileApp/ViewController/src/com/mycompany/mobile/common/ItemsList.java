package com.mycompany.mobile.common;

import java.lang.reflect.Array;

import oracle.adfmf.java.beans.PropertyChangeListener;
import oracle.adfmf.java.beans.PropertyChangeSupport;

//utility class to store items[] returned in ADF BC service
public class ItemsList<T>
{
   private T[] items;
   private int count = 0;
   private boolean hasMore = true;
   private int offset = 0;
   private PropertyChangeSupport propertyChangeSupport = new PropertyChangeSupport(this);

   //used to append the list
   public void append(ItemsList<T> newList, Class<T> classType)
   {
      if (newList != null && newList.getItems() != null)
      {
         //if no items present
         if (getItems() == null)
         {
            //add all attributes from new list to memeber attribute
            setItems(newList.getItems());
            setCount(newList.getCount());
            setHasMore(newList.isHasMore());
            setOffset(newList.getOffset());
            return;
         }

         int newItemsLength = newList.getItems().length;
         int currentItemsLength = getItems().length;

         //generic array type creation of combined length (existing item length + new items length
         @SuppressWarnings("unchecked")
         T[] concatenatedItems =
            (T[]) Array.newInstance(classType, newItemsLength + currentItemsLength);

         //copy the contents to intermediate array as we can't extend the current array
         System.arraycopy(getItems(), 0, concatenatedItems, 0, currentItemsLength);
         System.arraycopy(newList.getItems(), 0, concatenatedItems, currentItemsLength,
                          newItemsLength);

         //set the member attributes with concatenated array and other attributes
         setItems(concatenatedItems);
         setCount(newList.getCount());
         setHasMore(newList.isHasMore());
         setOffset(newList.getOffset());
      }
   }

   public void setItems(T[] items)
   {
      T[] oldItems = this.items;
      this.items = items;
      propertyChangeSupport.firePropertyChange("items", oldItems, items);
   }

   public T[] getItems()
   {
      return items;
   }

   public void setCount(int count)
   {
      int oldCount = this.count;
      this.count = count;
      propertyChangeSupport.firePropertyChange("count", oldCount, count);
   }

   public int getCount()
   {
      return count;
   }

   public void setHasMore(boolean hasMore)
   {
      boolean oldHasMore = this.hasMore;
      this.hasMore = hasMore;
      propertyChangeSupport.firePropertyChange("hasMore", oldHasMore, hasMore);
   }

   public boolean isHasMore()
   {
      return hasMore;
   }

   public void setOffset(int offset)
   {
      int oldOffset = this.offset;
      this.offset = offset;
      propertyChangeSupport.firePropertyChange("offset", oldOffset, offset);
   }

   public int getOffset()
   {
      return offset;
   }

   public int getEffOffset()
   {
      return getCount() + getOffset();
   }

   public void addPropertyChangeListener(PropertyChangeListener l)
   {
      propertyChangeSupport.addPropertyChangeListener(l);
   }

   public void removePropertyChangeListener(PropertyChangeListener l)
   {
      propertyChangeSupport.removePropertyChangeListener(l);
   }
}
