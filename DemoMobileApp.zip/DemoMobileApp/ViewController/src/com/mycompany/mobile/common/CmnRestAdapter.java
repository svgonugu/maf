package com.mycompany.mobile.common;


import java.lang.reflect.Array;
import java.util.Map;
import oracle.adfmf.dc.ws.rest.RestServiceAdapter;
import oracle.adfmf.framework.api.JSONBeanSerializationHelper;
import oracle.adfmf.framework.api.Model;
import oracle.adfmf.framework.exception.AdfException;
import oracle.adfmf.json.JSONArray;
import oracle.adfmf.json.JSONObject;
import oracle.adfmf.util.Utility;


//super class having all utitlity methods to perform service calls
public class CmnRestAdapter
{   
   public static RestServiceAdapter restAdapter = Model.createRestServiceAdapter();

   //connection name
   public static String connName = "RESTSVCCONN";
   public static String connURL;

   //media types
   public static final String jsonRsrcItemContentType =
      "application/vnd.oracle.adf.resourceitem+json";
   public static final String jsonRsrcCollContentType =
      "application/vnd.oracle.adf.resourcecollection+json";
   
   //HTTP PATCH
   public static final String REQUEST_TYPE_PATCH = "PATCH";

   //HTTP headers
   public static final String CONTENT_TYPE = "Content-Type";   

   //initilize the RestServiceAdapter with conn
   public static RestServiceAdapter initializeAdapter()
   {
      // Clear any previously set request properties, if any
      restAdapter.clearRequestProperties();

      //Set the connection name
      restAdapter.setConnectionName(connName);

      // Specify the number of retries
      restAdapter.setRetryLimit(1);
      return restAdapter;
   }

   //method to invoke service accepting HTTP method
   public static String invokeHTTPMethod(String httpMethod, String requestURI, String payload,
                                            Map<String, String> reqHeaders)
   {
      String response = "";

      initializeAdapter();

      //set http method
      restAdapter.setRequestType((httpMethod.equals(REQUEST_TYPE_PATCH)?
                                  RestServiceAdapter.REQUEST_TYPE_POST: httpMethod));

      if (reqHeaders != null && !reqHeaders.isEmpty())
      {
         reqHeaders.forEach((k, v) -> restAdapter.addRequestProperty(k, v));
         if (reqHeaders.get(CONTENT_TYPE) == null)
         {
            //set content type
            restAdapter.addRequestProperty(CONTENT_TYPE, jsonRsrcItemContentType);
         }
      }
      else
      {
         //set content type
         restAdapter.addRequestProperty(CONTENT_TYPE, jsonRsrcItemContentType);
      }

      //set request URI
      restAdapter.setRequestURI(requestURI);

      try
      {
         switch (httpMethod)
         {
            case RestServiceAdapter.REQUEST_TYPE_GET:
               response = restAdapter.send("");
               break;
            case RestServiceAdapter.REQUEST_TYPE_POST:
               response = restAdapter.send(payload);
               break;
            case RestServiceAdapter.REQUEST_TYPE_PUT:
               response = restAdapter.send(payload);
               break;
            case RestServiceAdapter.REQUEST_TYPE_DELETE:
               response = restAdapter.send("");
               break;
            case REQUEST_TYPE_PATCH:
               //tunnel the request as PATCH
               restAdapter.addRequestProperty("X-HTTP-Method-Override", "PATCH");
               response = restAdapter.send(payload);
               break;
         }
      }
      catch (Exception e)
      {
         //can give different error messages based on restAdapter.getResponseStatus()
         //here we are throwing generic error message
          String errMsg = (Utility.isEmpty(e.getCause().getMessage())? e.getMessage(): e.getCause().getMessage());
          throw new AdfException(errMsg,AdfException.ERROR);
      }
      return response;
   }

   //GET method
   public static String doGET(String requestURI, Map<String, String> reqHeaders)
   {      
      return invokeHTTPMethod(RestServiceAdapter.REQUEST_TYPE_GET, requestURI, null, reqHeaders);
   }

   //POST method
   public static String doPOST(String requestURI, String payload,
                                      Map<String, String> reqHeaders)
   {
      return invokeHTTPMethod(RestServiceAdapter.REQUEST_TYPE_POST, requestURI, payload, reqHeaders);
   }

   //PUT method
   public static String doPUT(String requestURI, String payload,
                                     Map<String, String> reqHeaders)
   {
      return invokeHTTPMethod(RestServiceAdapter.REQUEST_TYPE_PUT, requestURI, payload, reqHeaders);
   }

   //DELETE method
   public static String doDELETE(String requestURI, Map<String, String> reqHeaders)
   {
      return invokeHTTPMethod(RestServiceAdapter.REQUEST_TYPE_DELETE, requestURI, null, reqHeaders);
   }

   //PATCH method
   public static String doPATCH(String requestURI, String payload,
                                       Map<String, String> reqHeaders)
      throws Exception
   {
      return invokeHTTPMethod(REQUEST_TYPE_PATCH, requestURI, payload, reqHeaders);
   }

   //Utility method to deserialize JSON response into specific java class
   public static <T> ItemsList<T> deserializeToItemsList(String response, Class<T> classType)
      throws Exception
   {      
      if (Utility.isEmpty(response))
      {
         return null;
      }         

      ItemsList<T> itemList = new ItemsList<T>();
      
      //deserialize total JSON response
      JSONObject root =
         (JSONObject) JSONBeanSerializationHelper.fromJSON(JSONObject.class, response);

      //deserialize items[]
      JSONArray itemArray = (JSONArray) root.get("items");
      int size = itemArray.length();

      //initialize record count and all
      itemList.setHasMore(root.getBoolean("hasMore"));      
      itemList.setCount(root.getInt("count"));
      itemList.setOffset(root.getInt("offset"));

      //create generic array with size of JSONArray
      @SuppressWarnings("unchecked")
      T[] itemTypeArray = (T[]) Array.newInstance(classType, size);

      for (int i = 0; i < size; i++)
      {
         //insert element into generic array
         T elem =
            classType.cast(JSONBeanSerializationHelper.fromJSON(classType,
                                                                itemArray.getJSONObject(i)));
         itemTypeArray[i] = elem;
      }

      //set items
      itemList.setItems(itemTypeArray);
      return itemList;
   }

   //utility method to deserialize json to java class
//   public static Object jsonToClass(String className, String jsonPayload)
//   {
//      Object obj = ObjectFactory.createObject(className);
//      try
//      {
//         obj = JSONBeanSerializationHelper.fromJSON(obj.getClass(), jsonPayload);
//      }
//      catch (Exception e)
//      {
//         throw new AdfException("Error in deserializing",AdfException.ERROR);
//      }
//      return obj;
//   }
}