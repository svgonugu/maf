package com.mycompany.mobile.common;

import com.mycompany.mobile.entity.Department;

//factory method
public class ObjectFactory
{
   public static Object createObject(String className)
   {
      //instantiate the object based on class argument
      if ("Department".equalsIgnoreCase(className))
      {
         return new Department();
      }
      return null;
   }
}
